"""
Script d'entraînement principal.

Usage:
    python3 -m scripts.train \
        --images-train data/synthetic/images/train \
        --labels-train data/synthetic/labels/train \
        --images-val data/synthetic/images/val \
        --labels-val data/synthetic/labels/val \
        --epochs 20 --batch-size 8 --img-size 512

Le script :
  - charge les données via InpaintSegDataset (images + labels YOLO-seg -> masques)
  - entraîne ResNetUNet avec ComboLoss (BCE + Dice)
  - évalue IoU/Dice à chaque époque sur le split de validation
  - sauvegarde le meilleur checkpoint (selon IoU val) dans outputs/
"""

import argparse
import os
import time

import torch
from torch.utils.data import DataLoader

from data.dataset import InpaintSegDataset, get_train_transforms, get_val_transforms
from models.unet import ResNetUNet
from utils.losses import ComboLoss, compute_iou_dice


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--images-train", type=str, required=True)
    p.add_argument("--labels-train", type=str, required=True)
    p.add_argument("--images-val", type=str, required=True)
    p.add_argument("--labels-val", type=str, required=True)
    p.add_argument("--img-size", type=int, default=512)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--encoder-lr", type=float, default=1e-4)
    p.add_argument("--decoder-lr", type=float, default=1e-3)
    p.add_argument("--num-workers", type=int, default=2)
    p.add_argument("--out-dir", type=str, default="/home/claude/inpaint_seg/outputs")
    p.add_argument("--pretrained", dest="pretrained", action="store_true", default=True)
    p.add_argument("--no-pretrained", dest="pretrained", action="store_false")
    p.add_argument("--freeze-encoder-stages", type=int, default=0)
    p.add_argument("--early-stop-patience", type=int, default=8)
    return p.parse_args()


def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for batch in loader:
        images = batch["image"].to(device)
        masks = batch["mask"].to(device)

        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, masks)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
    return running_loss / len(loader.dataset)


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    ious, dices = [], []
    for batch in loader:
        images = batch["image"].to(device)
        masks = batch["mask"].to(device)

        logits = model(images)
        loss = criterion(logits, masks)
        running_loss += loss.item() * images.size(0)

        iou, dice = compute_iou_dice(logits, masks)
        ious.append(iou)
        dices.append(dice)

    avg_loss = running_loss / len(loader.dataset)
    avg_iou = sum(ious) / len(ious)
    avg_dice = sum(dices) / len(dices)
    return avg_loss, avg_iou, avg_dice


def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    train_ds = InpaintSegDataset(
        args.images_train, args.labels_train, img_size=args.img_size,
        transforms=get_train_transforms(args.img_size),
    )
    val_ds = InpaintSegDataset(
        args.images_val, args.labels_val, img_size=args.img_size,
        transforms=get_val_transforms(args.img_size),
    )
    print(f"Train: {len(train_ds)} images | Val: {len(val_ds)} images")

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=(device.type == "cuda"),
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, pin_memory=(device.type == "cuda"),
    )

    model = ResNetUNet(
        pretrained=args.pretrained,
        freeze_encoder_stages=args.freeze_encoder_stages,
    ).to(device)

    criterion = ComboLoss(bce_weight=0.5, dice_weight=0.5)
    optimizer = torch.optim.AdamW(
        model.get_param_groups(args.encoder_lr, args.decoder_lr)
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=3
    )

    best_iou = -1.0
    best_path = os.path.join(args.out_dir, "best_model.pt")
    patience_counter = 0

    history = []

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_iou, val_dice = validate(model, val_loader, criterion, device)
        scheduler.step(val_iou)
        dt = time.time() - t0

        current_lrs = [g["lr"] for g in optimizer.param_groups]
        print(
            f"[Epoch {epoch:03d}/{args.epochs}] "
            f"train_loss={train_loss:.4f} val_loss={val_loss:.4f} "
            f"val_IoU={val_iou:.4f} val_Dice={val_dice:.4f} "
            f"lrs={current_lrs} ({dt:.1f}s)"
        )
        history.append({
            "epoch": epoch, "train_loss": train_loss, "val_loss": val_loss,
            "val_iou": val_iou, "val_dice": val_dice,
        })

        if val_iou > best_iou:
            best_iou = val_iou
            patience_counter = 0
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "epoch": epoch,
                    "val_iou": val_iou,
                    "val_dice": val_dice,
                    "img_size": args.img_size,
                },
                best_path,
            )
            print(f"  -> nouveau meilleur modèle sauvegardé (IoU={val_iou:.4f}) dans {best_path}")
        else:
            patience_counter += 1
            if patience_counter >= args.early_stop_patience:
                print(f"Early stopping après {epoch} époques (pas d'amélioration depuis {args.early_stop_patience} époques).")
                break

    print(f"\nMeilleur IoU validation: {best_iou:.4f}")
    print(f"Checkpoint final: {best_path}")

    # Sauvegarde de l'historique pour analyse / courbes
    import json
    with open(os.path.join(args.out_dir, "history.json"), "w") as f:
        json.dump(history, f, indent=2)


if __name__ == "__main__":
    main()
