"""
Métrique custom pour Kaggle Code Competition — segmentation de zones inpaintées.

À COLLER dans le notebook Kaggle prévu pour la métrique (Host > Evaluation
Metric > Custom Python Metrics). Respecte la signature imposée par Kaggle :
    score(solution: pd.DataFrame, submission: pd.DataFrame, row_id_column_name: str) -> float

FORMAT DE SOUMISSION ATTENU (à adapter dans ton sample_submission.csv)
------------------------------------------------------------------
Comme un polygone a un nombre variable de points, on l'encode dans une
seule colonne string, espace-séparée, normalisée [0,1] :

    id              | polygon
    -----------------|----------------------------------------------
    img_0001         | 0.12 0.30 0.45 0.31 0.40 0.55 0.15 0.50
    img_0002         | 0.00 0.00 0.10 0.00 0.10 0.10 0.00 0.10 0.50 0.50 0.55 0.50 0.55 0.55 0.50 0.55
    img_0003         | (vide = pas de région prédite)

S'il y a plusieurs régions disjointes par image, on les concatène dans la
même cellule en les séparant par un point-virgule :
    "x1 y1 x2 y2 ... ; x1 y1 x2 y2 ..."

Le fichier solution.csv (vérité terrain, privé) doit avoir EXACTEMENT le
même format, plus une colonne 'width' et 'height' (taille originale de
l'image, nécessaire pour rasteriser les polygones en masques de façon
cohérente).
"""

from typing import List

import numpy as np
import pandas as pd
import pandas.api.types

try:
    import cv2
except ImportError as e:
    raise ImportError(
        "cv2 (opencv-python-headless) doit être installé dans l'environnement "
        "de scoring Kaggle. L'ajouter aux dépendances du notebook de métrique."
    ) from e


class ParticipantVisibleError(Exception):
    """Erreur dont le message est montré au participant (mauvais format, etc.)."""
    pass


def _parse_polygons(cell: str) -> List[np.ndarray]:
    """
    Parse une cellule 'polygon' -> liste de polygones (chacun un array Nx2,
    coordonnées normalisées [0,1]).
    Polygones multiples séparés par ';'. Cellule vide/NaN -> liste vide.
    """
    if cell is None:
        return []
    if isinstance(cell, float) and np.isnan(cell):
        return []
    cell = str(cell).strip()
    if not cell:
        return []

    polygons = []
    for poly_str in cell.split(";"):
        poly_str = poly_str.strip()
        if not poly_str:
            continue
        try:
            coords = np.array(poly_str.split(), dtype=np.float32)
        except ValueError:
            raise ParticipantVisibleError(
                f"Impossible de parser les coordonnées du polygone : '{poly_str[:60]}...'"
            )
        if coords.size % 2 != 0 or coords.size < 6:
            raise ParticipantVisibleError(
                "Chaque polygone doit avoir un nombre pair de valeurs "
                "(paires x,y) et au moins 3 points (6 valeurs)."
            )
        polygons.append(coords.reshape(-1, 2))
    return polygons


def _polygons_to_mask(polygons: List[np.ndarray], width: int, height: int) -> np.ndarray:
    mask = np.zeros((height, width), dtype=np.uint8)
    for poly in polygons:
        pts = poly.copy()
        pts[:, 0] = np.clip(pts[:, 0], 0.0, 1.0) * width
        pts[:, 1] = np.clip(pts[:, 1], 0.0, 1.0) * height
        pts = pts.round().astype(np.int32)
        cv2.fillPoly(mask, [pts], 1)
    return mask


def _iou(pred_mask: np.ndarray, gt_mask: np.ndarray) -> float:
    pred = pred_mask.astype(bool)
    gt = gt_mask.astype(bool)
    intersection = np.logical_and(pred, gt).sum()
    union = np.logical_or(pred, gt).sum()
    if union == 0:
        return 1.0  # ni pred ni gt -> accord parfait par convention
    return float(intersection) / float(union)


def score(
    solution: pd.DataFrame,
    submission: pd.DataFrame,
    row_id_column_name: str,
) -> float:
    """
    Score Kaggle = mean IoU (masque rasterisé) entre polygones soumis et
    polygones de vérité terrain, moyenné sur toutes les lignes (images).
    """
    # --- Validations de base ---
    if row_id_column_name not in solution.columns:
        raise ParticipantVisibleError(f"Colonne id manquante dans solution: {row_id_column_name}")
    if row_id_column_name not in submission.columns:
        raise ParticipantVisibleError(f"Colonne id manquante dans submission: {row_id_column_name}")
    if "polygon" not in submission.columns:
        raise ParticipantVisibleError("La colonne 'polygon' est requise dans la soumission.")
    if not pandas.api.types.is_string_dtype(submission["polygon"]) and not submission["polygon"].isna().all():
        # autorise quand même les colonnes object contenant des strings
        pass

    # --- Alignement des lignes par id ---
    solution = solution.sort_values(row_id_column_name).reset_index(drop=True)
    submission = submission.sort_values(row_id_column_name).reset_index(drop=True)

    if not (solution[row_id_column_name].values == submission[row_id_column_name].values).all():
        raise ParticipantVisibleError(
            "Les ids de la soumission ne correspondent pas exactement à ceux attendus."
        )

    ious = []
    for i in range(len(solution)):
        width = int(solution.loc[i, "width"])
        height = int(solution.loc[i, "height"])

        gt_polygons = _parse_polygons(solution.loc[i, "polygon"])
        pred_cell = submission.loc[i, "polygon"]
        pred_polygons = _parse_polygons(pred_cell)

        gt_mask = _polygons_to_mask(gt_polygons, width, height)
        pred_mask = _polygons_to_mask(pred_polygons, width, height)

        ious.append(_iou(pred_mask, gt_mask))

    return float(np.mean(ious))


# --------------------------------------------------------------------------
# Tests locaux (à exécuter avant publication de la métrique, comme recommandé
# par Kaggle : "Ensure a perfect submission yields a perfect score")
# --------------------------------------------------------------------------
if __name__ == "__main__":
    row_id_column_name = "id"

    solution = pd.DataFrame({
        "id": ["img_1", "img_2", "img_3"],
        "width": [100, 100, 100],
        "height": [100, 100, 100],
        "polygon": [
            "0.1 0.1 0.4 0.1 0.4 0.4 0.1 0.4",   # carré 30x30 normalisé
            "0.0 0.0 0.2 0.0 0.2 0.2 0.0 0.2",
            "",  # pas de région
        ],
    })

    # 1) Soumission PARFAITE -> doit donner 1.0
    perfect_submission = solution[["id", "polygon"]].copy()
    s = score(solution, perfect_submission, row_id_column_name)
    print(f"Soumission parfaite -> score = {s:.4f} (attendu: 1.0)")
    assert abs(s - 1.0) < 1e-6, "Une soumission parfaite doit donner un score parfait !"

    # 2) Soumission complètement à côté -> score bas
    bad_submission = pd.DataFrame({
        "id": ["img_1", "img_2", "img_3"],
        "polygon": [
            "0.6 0.6 0.9 0.6 0.9 0.9 0.6 0.9",  # ne recoupe pas le GT
            "0.6 0.6 0.9 0.6 0.9 0.9 0.6 0.9",
            "0.1 0.1 0.3 0.1 0.3 0.3 0.1 0.3",  # faux positif sur image vide
        ],
    })
    s_bad = score(solution, bad_submission, row_id_column_name)
    print(f"Soumission mauvaise -> score = {s_bad:.4f} (attendu: proche de 0)")

    # 3) Soumission vide partout -> doit donner un score correspondant
    #    (2/3 images sans GT donc IoU=1 par convention, 1/3 avec GT donc IoU=0)
    empty_submission = pd.DataFrame({
        "id": ["img_1", "img_2", "img_3"],
        "polygon": ["", "", ""],
    })
    s_empty = score(solution, empty_submission, row_id_column_name)
    print(f"Soumission vide -> score = {s_empty:.4f} (attendu: 0.3333)")

    print("\nTous les tests de cohérence sont passés.")
