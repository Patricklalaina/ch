"""
Scorer autonome pour le leaderboard du challenge "segmentation de zones
inpaintées". Indépendant de tout framework ML (juste opencv + numpy) afin
de pouvoir être branché tel quel dans l'infra d'évaluation, peu importe
comment les participants ont entraîné/produit leurs prédictions.

PRINCIPE
--------
On ne compare jamais les polygones point à point (sensible au nombre de
points, à l'ordre, au point de départ). On reconvertit prédictions et
vérité terrain en MASQUES BINAIRES à la résolution de l'image, et on
calcule l'IoU (+ Dice en complément) entre ces masques.

    IoU = |pred ∩ gt| / |pred ∪ gt|

Score final du leaderboard = moyenne des IoU sur toutes les images du
test set (la médiane est aussi affichée, plus robuste aux outliers).

FORMAT ATTENDU
--------------
- Un dossier de soumission contenant un fichier .txt par image, même
  basename que l'image, au format YOLO-seg :
      <class_id> x1 y1 x2 y2 ... xn yn   (coordonnées normalisées [0,1])
  Plusieurs lignes possibles par fichier = plusieurs régions disjointes.
  Toutes les classes sont traitées de façon identique (fusionnées en un
  masque binaire) : ce qui compte est la zone couverte, pas la classe.
- Un fichier .txt manquant ou vide pour une image = prédiction "aucune
  région inpaintée" (masque entièrement à 0).

USAGE
-----
    python3 score_submission.py \
        --pred-dir submissions/team_xyz/labels \
        --gt-dir   test_set/labels \
        --images-dir test_set/images \
        --out-csv results_team_xyz.csv

Affiche le score agrégé (mean IoU = score de classement) et écrit un CSV
détaillé par image (utile pour debug / détection de triche / outliers).
"""

import argparse
import csv
import os
from glob import glob
from typing import List, Tuple

import cv2
import numpy as np

IMG_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp", ".webp")


# --------------------------------------------------------------------------
# Lecture YOLO-seg + reconstruction de masque
# --------------------------------------------------------------------------

def read_yolo_seg_file(path: str) -> List[Tuple[int, np.ndarray]]:
    """Lit un .txt YOLO-seg -> liste de (class_id, polygon normalisé Nx2)."""
    polygons = []
    if not os.path.exists(path):
        return polygons
    with open(path, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 7:  # class_id + au moins 3 points
                continue
            try:
                class_id = int(float(parts[0]))
                coords = np.array(parts[1:], dtype=np.float32)
            except ValueError:
                continue  # ligne corrompue -> ignorée (pénalise déjà le participant)
            if coords.size % 2 != 0:
                continue
            polygons.append((class_id, coords.reshape(-1, 2)))
    return polygons


def polygons_to_mask(polygons: List[Tuple[int, np.ndarray]], w: int, h: int) -> np.ndarray:
    """Fusionne tous les polygones (toutes classes confondues) en un masque binaire (H, W)."""
    mask = np.zeros((h, w), dtype=np.uint8)
    for _, polygon in polygons:
        pts = polygon.copy()
        pts[:, 0] = np.clip(pts[:, 0], 0.0, 1.0) * w
        pts[:, 1] = np.clip(pts[:, 1], 0.0, 1.0) * h
        pts = pts.round().astype(np.int32)
        if pts.shape[0] >= 3:
            cv2.fillPoly(mask, [pts], color=1)
    return mask


# --------------------------------------------------------------------------
# Métriques
# --------------------------------------------------------------------------

def iou_dice(pred_mask: np.ndarray, gt_mask: np.ndarray) -> Tuple[float, float]:
    pred = pred_mask.astype(bool)
    gt = gt_mask.astype(bool)

    intersection = np.logical_and(pred, gt).sum()
    union = np.logical_or(pred, gt).sum()

    if union == 0:
        # ni prédiction ni vérité terrain -> accord parfait par convention
        return 1.0, 1.0

    iou = intersection / union
    dice = 2 * intersection / (pred.sum() + gt.sum() + 1e-9)
    return float(iou), float(dice)


# --------------------------------------------------------------------------
# Boucle principale de scoring
# --------------------------------------------------------------------------

def score_submission(pred_dir: str, gt_dir: str, images_dir: str, out_csv: str = None):
    image_paths = sorted(
        p for p in glob(os.path.join(images_dir, "*")) if p.lower().endswith(IMG_EXTENSIONS)
    )
    if not image_paths:
        raise FileNotFoundError(f"Aucune image trouvée dans {images_dir}")

    rows = []
    n_missing_pred = 0
    n_empty_gt = 0

    for img_path in image_paths:
        basename = os.path.splitext(os.path.basename(img_path))[0]

        img = cv2.imread(img_path)
        if img is None:
            print(f"[WARN] image illisible, ignorée : {img_path}")
            continue
        h, w = img.shape[:2]

        gt_path = os.path.join(gt_dir, basename + ".txt")
        pred_path = os.path.join(pred_dir, basename + ".txt")

        gt_polygons = read_yolo_seg_file(gt_path)
        gt_mask = polygons_to_mask(gt_polygons, w, h)
        if gt_mask.sum() == 0:
            n_empty_gt += 1

        if not os.path.exists(pred_path):
            n_missing_pred += 1
            pred_mask = np.zeros((h, w), dtype=np.uint8)
        else:
            pred_polygons = read_yolo_seg_file(pred_path)
            pred_mask = polygons_to_mask(pred_polygons, w, h)

        iou, dice = iou_dice(pred_mask, gt_mask)
        rows.append({
            "image": basename,
            "iou": round(iou, 6),
            "dice": round(dice, 6),
            "gt_area_px": int(gt_mask.sum()),
            "pred_area_px": int(pred_mask.sum()),
            "pred_missing": pred_path is None or not os.path.exists(pred_path),
        })

    ious = [r["iou"] for r in rows]
    dices = [r["dice"] for r in rows]

    summary = {
        "n_images": len(rows),
        "n_missing_predictions": n_missing_pred,
        "n_empty_gt": n_empty_gt,
        "mean_iou": float(np.mean(ious)),
        "median_iou": float(np.median(ious)),
        "mean_dice": float(np.mean(dices)),
    }

    print("=" * 50)
    print(f"Images évaluées      : {summary['n_images']}")
    print(f"Prédictions manquantes: {summary['n_missing_predictions']}")
    print(f"GT vides (sans zone)  : {summary['n_empty_gt']}")
    print("-" * 50)
    print(f"SCORE LEADERBOARD (mean IoU) : {summary['mean_iou']:.4f}")
    print(f"Median IoU                   : {summary['median_iou']:.4f}")
    print(f"Mean Dice                    : {summary['mean_dice']:.4f}")
    print("=" * 50)

    if out_csv:
        with open(out_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        print(f"Détail par image écrit dans : {out_csv}")

    return summary, rows


def parse_args():
    p = argparse.ArgumentParser(description="Scorer le leaderboard (IoU mask-based)")
    p.add_argument("--pred-dir", required=True, help="Dossier des .txt YOLO-seg soumis")
    p.add_argument("--gt-dir", required=True, help="Dossier des .txt YOLO-seg de vérité terrain")
    p.add_argument("--images-dir", required=True, help="Dossier des images du test set")
    p.add_argument("--out-csv", default=None, help="Chemin du CSV détaillé (optionnel)")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    score_submission(args.pred_dir, args.gt_dir, args.images_dir, args.out_csv)
